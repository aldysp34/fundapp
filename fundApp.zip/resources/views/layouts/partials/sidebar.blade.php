

<div class="mdk-drawer js-mdk-drawer" id="default-drawer">
    <div class="mdk-drawer__content">
        <div class="sidebar sidebar-dark sidebar-left" data-perfect-scrollbar>
            <div class="sidebar-brand ">
                <img class="sidebar-brand-icon"
                        src="{{asset('assets/images/kabBekasi.svg')}}"
                        alt="Huma">
                <span>PEPARDA</span>
                <span>KABUPATEN</span>
                <span>BEKASI</span>
            </div>
            @yield('sidebar-content')
        </div>
    </div>
</div>
